# Regional Sales Dashboard | Power BI

An interactive regional sales performance dashboard developed in Microsoft Power BI. This project presents sales information through visual reporting to support geographic comparisons and business performance exploration.

## Project overview

The report is designed to make regional sales information easier to explore, compare, and communicate. It demonstrates how Power BI can turn tabular business data into an accessible visual reporting experience.

## Analysis focus

- Regional sales performance and comparison
- Visual exploration of sales information
- Interactive filtering and report navigation, where available
- Review of report pages and the underlying data model

> Specific KPIs, geographic fields, and business dimensions should be confirmed from the PBIX data model and report pages before drawing conclusions.

## Tools and techniques

- **Microsoft Power BI Desktop** — report development and visualization
- **Power Query** — data preparation, where used in the report
- **DAX** — measures and calculations, where implemented

## Repository contents

| File | Description |
|---|---|
| `Regional Sales Sample.pbix` | Editable Power BI Desktop report |

## Open the project

1. Download and extract this ZIP archive.
2. Install and open Microsoft Power BI Desktop.
3. Open `Regional Sales Sample.pbix`.
4. If Power BI prompts for a missing source, reconnect the dataset or update its path.
5. Refresh the report after confirming the data connection.

## Portfolio highlights

This project demonstrates:
- Building a business-focused sales dashboard
- Comparing performance across regions
- Presenting business data through visual analytics
- Exploring report filters, data relationships, and calculations

## Notes

- The PBIX file is the main project deliverable.
- Data refresh requirements depend on the source connections saved in the report.
- Confirm sales metric definitions and regional groupings before presenting business findings.

---
**Project category:** Business Intelligence / Sales Analytics  
**Primary tool:** Microsoft Power BI
